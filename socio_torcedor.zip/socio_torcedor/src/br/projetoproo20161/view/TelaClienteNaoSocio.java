package br.projetoproo20161.view;

import javax.swing.JOptionPane;

public class TelaClienteNaoSocio {
	
	public TelaClienteNaoSocio() {
		
		JOptionPane.showInputDialog("ol�");
	}

}
