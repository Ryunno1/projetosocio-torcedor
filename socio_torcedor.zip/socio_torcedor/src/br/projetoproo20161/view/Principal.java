package br.projetoproo20161.view;

public class Principal {

	public static void main(String[] args) {
		
		TelaPrincipal t = new TelaPrincipal();
		
		
	}

}
