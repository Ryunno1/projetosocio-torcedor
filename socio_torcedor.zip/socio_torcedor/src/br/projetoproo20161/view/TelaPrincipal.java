package br.projetoproo20161.view;

import javax.swing.JOptionPane;

public class TelaPrincipal {
	
	public TelaPrincipal() {
		
		
		JOptionPane.showInputDialog("Bem Vindo  escolha a op��o que deseja fazer\n"
				+ "1 - Para se cadastrar\n"
				+ "2 - Para entrar\n"
				+ "3 - N�o tenho cadastro e n�o quero me cadastrar s� desejo comprar");
	}

}
