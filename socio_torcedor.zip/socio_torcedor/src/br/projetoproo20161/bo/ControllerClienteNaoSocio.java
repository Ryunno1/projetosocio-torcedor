package br.projetoproo20161.bo;

import br.projetoproo20161.modelo.Cliente;
import br.projetoproo20161.modelo.Cliente_nao_socio;

public class ControllerClienteNaoSocio extends Cliente_nao_socio{

	
}
