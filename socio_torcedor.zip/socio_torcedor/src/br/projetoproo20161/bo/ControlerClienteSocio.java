package br.projetoproo20161.bo;

import br.projetoproo20161.modelo.Cliente;
import br.projetoproo20161.modelo.Cliente_socio;

public class ControlerClienteSocio extends Cliente_socio {
	


void comprarIngresso (Integer qtd){
		
    }
	
void comprarIngressoCaravana (Integer qtd){
    	
    }

}
