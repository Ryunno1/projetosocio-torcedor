package br.projetoproo20161.bo;

import br.projetoproo20161.modelo.Funcionario;

public class ControllerFuncionario extends Funcionario{

void cadastrarIngresso (){
		
    }

void cadastrarIngressoMaisCaravana (){
	
	
}
}
