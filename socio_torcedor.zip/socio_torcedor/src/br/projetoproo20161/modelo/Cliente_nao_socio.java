package br.projetoproo20161.modelo;

public class Cliente_nao_socio extends Cliente {

}
