package br.projetoproo20161.modelo;

public class Cliente_socio extends Cliente{
	
	
}
